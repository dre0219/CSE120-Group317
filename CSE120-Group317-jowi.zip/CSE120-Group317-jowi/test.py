# from contextlib import redirect_stderr
# import sqlite3
# from ast import Slice
# from re import S
# from flask import Flask, request, jsonify, render_template, url_for, current_app, g, redirect
# from flask.cli import with_appcontext
# from flask_sqlalchemy import SQLAlchemy
# from flask_cors import CORS
# from flask_restful import Api, Resource, reqparse
# import json

# app = Flask(__name__)
# api = Api(app)
# CORS(app)



# if __name__ == "__main__":
#     app.run(debug=True)